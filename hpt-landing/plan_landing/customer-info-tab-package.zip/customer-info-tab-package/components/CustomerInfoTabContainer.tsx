import React, { useCallback } from 'react';
import { CustomerInfoTabProps, DEFAULT_SECTIONS, SECTION_TYPES } from '../types';
import { useCustomerInfoState, useMemoManagement, useTagManagement } from '../hooks/useCustomerInfoState';
import { useFieldVisibility } from '../hooks/useFieldVisibility';
import SectionWrapper from './SectionWrapper';
import CustomerInfoSection from './sections/CustomerInfoSection';
import CustomerMemoSection from './sections/CustomerMemoSection';
import CustomerTagSection from './sections/CustomerTagSection';

const CustomerInfoTabContainer: React.FC<CustomerInfoTabProps> = ({
  customerData,
  sections: propSections,
  customSections = [],
  visibleFields: propVisibleFields,
  onToggleFieldVisibility: propOnToggleFieldVisibility,
  columnSettings: propColumnSettings,
  onToggleColumnSetting: propOnToggleColumnSetting,
  memos: propMemos,
  onAddMemo: propOnAddMemo,
  onEditMemo: propOnEditMemo,
  onDeleteMemo: propOnDeleteMemo,
  tags: propTags,
  onAddTag: propOnAddTag,
  onEditTag: propOnEditTag,
  onDeleteTag: propOnDeleteTag,
  customerInfoRenderer,
  customerMemoRenderer,
  customerTagRenderer,
  isCustomerInfoOverlayOpen,
  onToggleCustomerInfoOverlay,
  onSectionReorder,
  apiSettings,
  className = '',
  sectionClassName = '',
}) => {
  const initialSections = propSections || DEFAULT_SECTIONS;

  const { sections, handleDragStart, handleDrop, updateSectionSettings } = useCustomerInfoState(initialSections);

  const internalFieldVisibility = useFieldVisibility(propVisibleFields);
  const internalMemoManagement = useMemoManagement(propMemos);
  const internalTagManagement = useTagManagement(propTags);

  const visibleFields = propVisibleFields || internalFieldVisibility.visibleFields;
  const columnSettings = propColumnSettings || internalFieldVisibility.columnSettings;

  const toggleFieldVisibility = propOnToggleFieldVisibility || internalFieldVisibility.toggleFieldVisibility;
  const toggleColumnSetting = propOnToggleColumnSetting || internalFieldVisibility.toggleColumnSetting;

  const memos = propMemos || internalMemoManagement.memos;
  const addMemo = propOnAddMemo || internalMemoManagement.addMemo;
  const editMemo = propOnEditMemo || internalMemoManagement.editMemo;
  const deleteMemo = propOnDeleteMemo || internalMemoManagement.deleteMemo;

  const tags = propTags || internalTagManagement.tags;
  const addTag = propOnAddTag || internalTagManagement.addTag;
  const editTag = propOnEditTag || internalTagManagement.editTag;
  const deleteTag = propOnDeleteTag || internalTagManagement.deleteTag;

  const defaultCustomerData = {
    name: '김고객',
    email: 'customer@example.com',
    phone: '+1 (555) 123-4567',
    customerId: '6fa36417-c923-4cee-aa54-cfbb3',
  };

  const data = customerData || defaultCustomerData;

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  }, []);

  const handleDropWrapper = useCallback(
    (e: React.DragEvent, targetSectionId: string) => {
      const draggedId = e.dataTransfer.getData('text/plain');
      const newSections = handleDrop(targetSectionId, draggedId);
      if (onSectionReorder) {
        onSectionReorder(newSections);
      }
    },
    [handleDrop, onSectionReorder]
  );

  const renderSectionContent = (section: typeof sections[0]) => {
    const customSection = customSections.find(cs => cs.section.id === section.id);
    if (customSection) {
      return customSection.renderContent(data);
    }

    switch (section.type) {
      case SECTION_TYPES.CUSTOMER_INFO:
        if (customerInfoRenderer) {
          return customerInfoRenderer(data, { visibleFields, columnSettings });
        }
        return (
          <CustomerInfoSection
            data={data}
            visibleFields={visibleFields}
            columnSettings={columnSettings}
          />
        );

      case SECTION_TYPES.CUSTOMER_MEMO:
        if (customerMemoRenderer) {
          return customerMemoRenderer(memos, { addMemo, editMemo, deleteMemo });
        }
        return (
          <CustomerMemoSection
            memos={memos}
            onAddMemo={addMemo}
            onEditMemo={editMemo}
            onDeleteMemo={deleteMemo}
          />
        );

      case SECTION_TYPES.CUSTOMER_TAG:
        if (customerTagRenderer) {
          return customerTagRenderer(tags, { addTag, editTag, deleteTag });
        }
        return (
          <CustomerTagSection
            tags={tags}
            onAddTag={addTag}
            onDeleteTag={deleteTag}
          />
        );

      default:
        return <div className="text-gray-500 text-center py-4">Unknown section type</div>;
    }
  };

  const sortedSections = [...sections].sort((a, b) => a.order - b.order);

  return (
    <div className={`h-full flex flex-col ${className}`}>
      <div className="flex-1 overflow-y-auto">
        {sortedSections.map((section) => (
          <SectionWrapper
            key={section.id}
            sectionId={section.id}
            title={section.name}
            initialCollapsed={section.isCollapsed}
            onDragStart={handleDragStart}
            onDragOver={handleDragOver}
            onDrop={handleDropWrapper}
            showSettings={section.type !== SECTION_TYPES.CUSTOMER_MEMO}
            showIntegration={section.type === SECTION_TYPES.CUSTOMER_INFO}
            showOverlay={section.type === SECTION_TYPES.CUSTOMER_INFO}
            onOpenOverlay={onToggleCustomerInfoOverlay ? () => onToggleCustomerInfoOverlay(true) : undefined}
          >
            {renderSectionContent(section)}
          </SectionWrapper>
        ))}

        {customSections
          .filter(cs => !sections.find(s => s.id === cs.section.id))
          .map(({ section, renderContent }) => (
            <SectionWrapper
              key={section.id}
              sectionId={section.id}
              title={section.name}
              initialCollapsed={section.isCollapsed}
              onDragStart={handleDragStart}
              onDragOver={handleDragOver}
              onDrop={handleDropWrapper}
              showSettings={false}
            >
              {renderContent(data)}
            </SectionWrapper>
          ))}
      </div>
    </div>
  );
};

export default CustomerInfoTabContainer;
