import React, { useState } from 'react';
import { Hash, Trash2, User, Plus } from 'lucide-react';
import { Tag } from '../../types';
import TagSelectionModal from '../modals/TagSelectionModal';

interface CustomerTagSectionProps {
  tags: Tag[];
  onAddTag: (name: string, color: string) => void;
  onDeleteTag: (tagId: number) => void;
  maxTags?: number;
}

const CustomerTagSection: React.FC<CustomerTagSectionProps> = ({
  tags,
  onAddTag,
  onDeleteTag,
  maxTags = 20,
}) => {
  const [isTagModalOpen, setIsTagModalOpen] = useState(false);

  const getTextColor = (bgColor: string) => {
    const colorMap: { [key: string]: string } = {
      'bg-blue-300': 'text-blue-800',
      'bg-green-300': 'text-green-800',
      'bg-red-300': 'text-red-800',
      'bg-yellow-200': 'text-yellow-800',
      'bg-purple-300': 'text-purple-800',
      'bg-pink-300': 'text-pink-800',
      'bg-gray-300': 'text-gray-800',
      'bg-orange-300': 'text-orange-800',
    };
    return colorMap[bgColor] || 'text-gray-800';
  };

  const handleModalAddTag = (name: string, color: string) => {
    onAddTag(name, color);
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      {tags.map((tag) => (
        <div key={tag.id} className="group relative">
          <div
            className={`inline-flex items-center px-3 py-2 rounded-full text-sm font-medium ${
              tag.color
            } ${getTextColor(tag.color)} relative`}
          >
            <Hash size={12} className="mr-1" />
            {tag.name}

            <div className="absolute -top-1 -right-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={() => onDeleteTag(tag.id)}
                className="w-5 h-5 bg-white text-gray-600 hover:text-red-600 rounded-full flex items-center justify-center text-xs shadow-md"
                title="태그 삭제"
              >
                <Trash2 size={10} />
              </button>
            </div>
          </div>

          <div className="absolute bottom-full left-0 mb-1 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
            <div className="bg-gray-800 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
              <div className="flex items-center gap-1">
                <User size={10} />
                {tag.createdBy}
              </div>
              <div>{tag.createdAt}</div>
            </div>
          </div>
        </div>
      ))}

      <button
        onClick={() => setIsTagModalOpen(true)}
        disabled={tags.length >= maxTags}
        className="inline-flex items-center px-3 py-2 border-2 border-dashed border-gray-300 rounded-full text-sm font-medium text-gray-500 hover:border-blue-400 hover:text-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        title={tags.length >= maxTags ? `최대 태그 개수에 도달했습니다` : '태그 추가'}
      >
        <Plus size={12} className="mr-1" />
        태그 추가 ({tags.length}/{maxTags})
      </button>

      <TagSelectionModal
        isOpen={isTagModalOpen}
        onClose={() => setIsTagModalOpen(false)}
        onAddTag={handleModalAddTag}
        onRemoveTag={onDeleteTag}
        existingTags={tags}
      />
    </div>
  );
};

export default CustomerTagSection;
