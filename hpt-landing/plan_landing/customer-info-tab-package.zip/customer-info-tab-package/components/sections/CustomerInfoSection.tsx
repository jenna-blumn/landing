import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { CustomerInfo } from '../../types';
import { getAllFieldDefinitions } from '../../utils/fieldDefinitions';
import { copyToClipboard } from '../../utils/copyToClipboard';

interface CustomerInfoSectionProps {
  data: CustomerInfo;
  visibleFields: Set<string>;
  columnSettings: Set<string>;
  onFieldCopy?: (fieldId: string, value: string) => void;
}

const CustomerInfoSection: React.FC<CustomerInfoSectionProps> = ({
  data,
  visibleFields,
  columnSettings,
  onFieldCopy,
}) => {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [copiedItem, setCopiedItem] = useState<string | null>(null);

  const allItems = getAllFieldDefinitions(data);
  const visibleItems = allItems.filter(item => visibleFields.has(item.id));

  const handleCopyToClipboard = async (value: string, itemId: string) => {
    const success = await copyToClipboard(value);
    if (success) {
      setCopiedItem(itemId);
      setTimeout(() => setCopiedItem(null), 2000);
      if (onFieldCopy) {
        onFieldCopy(itemId, value);
      }
    }
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2">
        {visibleItems.map((item) => (
          <div
            key={item.id}
            className={`flex items-center py-1 sm:flex-col sm:items-start lg:flex-row lg:items-center relative ${
              columnSettings.has(item.id) ? 'sm:col-span-2' : ''
            }`}
            onMouseEnter={() => setHoveredItem(item.id)}
            onMouseLeave={() => setHoveredItem(null)}
          >
            <span className="text-sm text-gray-600 font-medium min-w-[80px] md:min-w-0 lg:min-w-[80px] md:mb-1 lg:mb-0">
              {item.label}:
            </span>
            <div className="flex items-center flex-1 ml-2 sm:ml-0 lg:ml-2 min-w-0">
              <span
                className={`text-sm ${
                  item.color || 'text-gray-800'
                } text-left truncate flex-1`}
                title={String(item.value)}
              >
                {item.value || '미확인'}
              </span>

              {hoveredItem === item.id && (
                <button
                  onClick={() => handleCopyToClipboard(String(item.value) || '', item.id)}
                  className="ml-2 p-1 hover:bg-gray-200 rounded transition-colors flex-shrink-0"
                  title="복사"
                >
                  {copiedItem === item.id ? (
                    <Check size={12} className="text-green-600" />
                  ) : (
                    <Copy size={12} className="text-gray-500" />
                  )}
                </button>
              )}
            </div>

            {hoveredItem === item.id && item.value && String(item.value).length > 20 && (
              <div className="absolute left-0 top-full mt-1 bg-gray-800 text-white text-xs px-2 py-1 rounded whitespace-nowrap z-50 shadow-lg">
                {item.value}
                <div className="absolute bottom-full left-4 w-0 h-0 border-l-4 border-r-4 border-b-4 border-l-transparent border-r-transparent border-b-gray-800"></div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default CustomerInfoSection;
