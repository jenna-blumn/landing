import React, { useState } from 'react';
import { User, Edit, Save, X, Trash2 } from 'lucide-react';
import { Memo } from '../../types';

interface CustomerMemoSectionProps {
  memos: Memo[];
  onAddMemo: (content: string) => void;
  onEditMemo: (memoId: number, newContent: string) => void;
  onDeleteMemo: (memoId: number) => void;
}

const CustomerMemoSection: React.FC<CustomerMemoSectionProps> = ({
  memos,
  onAddMemo,
  onEditMemo,
  onDeleteMemo,
}) => {
  const [newMemo, setNewMemo] = useState('');
  const [editingMemoId, setEditingMemoId] = useState<number | null>(null);
  const [editingContent, setEditingContent] = useState('');

  const handleAddMemo = () => {
    if (newMemo.trim()) {
      onAddMemo(newMemo);
      setNewMemo('');
    }
  };

  const handleStartEdit = (memo: Memo) => {
    setEditingMemoId(memo.id);
    setEditingContent(memo.content);
  };

  const handleSaveEdit = () => {
    if (editingMemoId && editingContent.trim()) {
      onEditMemo(editingMemoId, editingContent.trim());
      setEditingMemoId(null);
      setEditingContent('');
    }
  };

  const handleCancelEdit = () => {
    setEditingMemoId(null);
    setEditingContent('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleAddMemo();
    }
  };

  const handleEditKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleSaveEdit();
    } else if (e.key === 'Escape') {
      handleCancelEdit();
    }
  };

  return (
    <div className="space-y-4">
      <div className="relative border rounded-lg bg-white shadow-sm">
        <textarea
          value={newMemo}
          onChange={(e) => setNewMemo(e.target.value)}
          placeholder="새 고객 메모를 작성하세요"
          className="w-full p-3 pr-16 border-gray-300 rounded-lg resize-none h-16 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          onKeyDown={handleKeyPress}
          maxLength={500}
        />
        <div className="absolute bottom-2 right-2 text-xs text-gray-400 bg-white px-1 rounded flex items-center gap-1">
          <span className="text-gray-400">Ctrl+Enter</span>
          <span className="text-gray-300">•</span>
          {newMemo.length}/500
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="font-medium text-gray-800">메모 목록</h4>
          <span className="text-sm text-gray-500">{memos.length}개</span>
        </div>

        <div className="max-h-64 overflow-y-auto space-y-3">
          {memos.map((memo) => (
            <div key={memo.id} className="border rounded-lg p-3 bg-white shadow-sm">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <User size={16} className="text-gray-500 flex-shrink-0" />
                  <div className="min-w-0">
                    <span className="text-sm font-medium text-gray-700">
                      {memo.author}
                    </span>
                    <span className="text-xs text-gray-500 ml-2">
                      {memo.createdAt}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {editingMemoId !== memo.id && (
                    <button
                      onClick={() => handleStartEdit(memo)}
                      className="p-1 text-gray-400 hover:text-blue-500 transition-colors"
                      title="메모 수정"
                    >
                      <Edit size={14} />
                    </button>
                  )}
                  <button
                    onClick={() => onDeleteMemo(memo.id)}
                    className="p-1 text-gray-400 hover:text-red-500 transition-colors flex-shrink-0"
                    title="메모 삭제"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>

              {editingMemoId === memo.id ? (
                <div className="pl-6">
                  <div className="relative">
                    <textarea
                      value={editingContent}
                      onChange={(e) => setEditingContent(e.target.value)}
                      className="w-full p-2 pr-12 border rounded text-sm resize-none h-20 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      onKeyDown={handleEditKeyPress}
                      maxLength={500}
                      autoFocus
                    />
                    <div className="absolute bottom-1 right-1 text-xs text-gray-400 bg-white px-1 rounded flex items-center gap-1">
                      <span className="text-gray-400">Ctrl+Enter</span>
                      <span className="text-gray-300">•</span>
                      {editingContent.length}/500
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <button
                      onClick={handleSaveEdit}
                      disabled={!editingContent.trim()}
                      className="px-2 py-1 bg-green-500 hover:bg-green-600 text-white rounded text-xs font-medium disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-1"
                    >
                      <Save size={12} />
                      저장
                    </button>
                    <button
                      onClick={handleCancelEdit}
                      className="px-2 py-1 bg-gray-500 hover:bg-gray-600 text-white rounded text-xs font-medium flex items-center gap-1"
                    >
                      <X size={12} />
                      취소
                    </button>
                    <span className="text-xs text-gray-500">Ctrl+Enter로 저장, Esc로 취소</span>
                  </div>
                </div>
              ) : (
                <div className="text-sm text-gray-800 whitespace-pre-wrap pl-6">
                  {memo.content}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CustomerMemoSection;
