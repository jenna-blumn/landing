import React, { useState, useRef } from 'react';
import { ChevronDown, ChevronUp, GripVertical, Settings, Eye, Link } from 'lucide-react';

interface SectionWrapperProps {
  sectionId: string;
  title: string;
  children: React.ReactNode;
  initialCollapsed?: boolean;
  onDragStart: (e: React.DragEvent, sectionId: string) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent, targetSectionId: string) => void;
  onSectionSettingsClick?: (sectionId: string) => void;
  onIntegrationClick?: (sectionId: string) => void;
  onOpenOverlay?: () => void;
  showSettings?: boolean;
  showIntegration?: boolean;
  showOverlay?: boolean;
}

const SectionWrapper: React.FC<SectionWrapperProps> = ({
  sectionId,
  title,
  children,
  initialCollapsed = false,
  onDragStart,
  onDragOver,
  onDrop,
  onSectionSettingsClick,
  onIntegrationClick,
  onOpenOverlay,
  showSettings = true,
  showIntegration = false,
  showOverlay = false,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(initialCollapsed);
  const [isDragOver, setIsDragOver] = useState(false);
  const [isSettingsDropdownOpen, setIsSettingsDropdownOpen] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData('text/plain', sectionId);
    e.dataTransfer.effectAllowed = 'move';
    onDragStart(e, sectionId);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setIsDragOver(true);
    onDragOver(e);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    onDrop(e, sectionId);
  };

  const handleSettingsDropdownToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsSettingsDropdownOpen(!isSettingsDropdownOpen);
  };

  const handleDropdownItemClick = (action: 'overlay' | 'api' | 'integration') => {
    setIsSettingsDropdownOpen(false);

    switch (action) {
      case 'overlay':
        if (onOpenOverlay) onOpenOverlay();
        break;
      case 'api':
        if (onSectionSettingsClick) onSectionSettingsClick(sectionId);
        break;
      case 'integration':
        if (onIntegrationClick) onIntegrationClick(sectionId);
        break;
    }
  };

  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (sectionRef.current && !sectionRef.current.contains(event.target as Node)) {
        setIsSettingsDropdownOpen(false);
      }
    };

    if (isSettingsDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isSettingsDropdownOpen]);

  return (
    <div
      ref={sectionRef}
      className={`border rounded-lg bg-white mb-2 transition-all duration-200 ${
        isDragOver ? 'border-blue-400 bg-blue-50 shadow-md' : 'border-gray-200'
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <div className="flex items-center p-3 border-b border-gray-100">
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="flex items-center gap-2 flex-1 text-left hover:text-purple-700 transition-colors"
        >
          <span className="font-medium text-purple-800">{title}</span>
          {isCollapsed ? (
            <ChevronDown size={16} className="text-purple-600" />
          ) : (
            <ChevronUp size={16} className="text-purple-600" />
          )}
        </button>

        {!isCollapsed && (
          <div className="flex items-center gap-1 ml-2">
            {showIntegration && onIntegrationClick && (
              <button
                onClick={() => onIntegrationClick(sectionId)}
                className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                title="고객 정보 연동"
              >
                <Link size={16} />
              </button>
            )}

            {(showSettings || showOverlay) && (
              <div className="relative">
                <button
                  onClick={handleSettingsDropdownToggle}
                  className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                  title="섹션 설정"
                >
                  <Settings size={16} />
                </button>

                {isSettingsDropdownOpen && (
                  <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-50 min-w-[180px]">
                    <div className="py-1">
                      {showOverlay && onOpenOverlay && (
                        <button
                          onClick={() => handleDropdownItemClick('overlay')}
                          className="w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                        >
                          <Eye size={14} />
                          모든 정보 보기
                        </button>
                      )}

                      {showSettings && onSectionSettingsClick && (
                        <button
                          onClick={() => handleDropdownItemClick('api')}
                          className="w-full px-3 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                        >
                          <Settings size={14} />
                          API 설정
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            <div
              className="cursor-move p-1 ml-2 text-gray-400 hover:text-gray-600 transition-colors"
              draggable
              onDragStart={handleDragStart}
              title="Drag to reorder section"
            >
              <GripVertical size={16} />
            </div>
          </div>
        )}

        {isCollapsed && (
          <div className="flex items-center gap-1 ml-2">
            <div
              className="cursor-move p-1 text-gray-400 hover:text-gray-600 transition-colors"
              draggable
              onDragStart={handleDragStart}
              title="Drag to reorder section"
            >
              <GripVertical size={16} />
            </div>
          </div>
        )}

        {isSettingsDropdownOpen && (
          <div className="fixed inset-0 z-40" onClick={() => setIsSettingsDropdownOpen(false)} />
        )}
      </div>

      {!isCollapsed && <div className="p-3">{children}</div>}
    </div>
  );
};

export default SectionWrapper;
