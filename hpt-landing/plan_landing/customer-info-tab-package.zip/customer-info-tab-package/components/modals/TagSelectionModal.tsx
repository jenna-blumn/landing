import React, { useState, useRef, useEffect } from 'react';
import { X, Hash, Check } from 'lucide-react';
import { Tag } from '../../types';

interface TagSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTag: (name: string, color: string) => void;
  onRemoveTag: (tagId: number) => void;
  existingTags: Tag[];
  availableTags?: Tag[];
}

const PREDEFINED_TAGS = [
  { name: 'VIP고객', color: 'bg-red-300' },
  { name: '우선처리', color: 'bg-orange-300' },
  { name: '단골고객', color: 'bg-blue-300' },
  { name: '신규고객', color: 'bg-green-300' },
  { name: '문제고객', color: 'bg-yellow-200' },
];

const TagSelectionModal: React.FC<TagSelectionModalProps> = ({
  isOpen,
  onClose,
  onAddTag,
  onRemoveTag,
  existingTags,
  availableTags,
}) => {
  const [filterText, setFilterText] = useState('');
  const [newTagColor, setNewTagColor] = useState('bg-gray-300');
  const [showColorPicker, setShowColorPicker] = useState(false);

  const colorPickerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const availableColors = [
    { value: 'bg-blue-300', label: '파란색', textColor: 'text-blue-800' },
    { value: 'bg-green-300', label: '초록색', textColor: 'text-green-800' },
    { value: 'bg-red-300', label: '빨간색', textColor: 'text-red-800' },
    { value: 'bg-yellow-200', label: '노란색', textColor: 'text-yellow-800' },
    { value: 'bg-purple-300', label: '보라색', textColor: 'text-purple-800' },
    { value: 'bg-pink-300', label: '분홍색', textColor: 'text-pink-800' },
    { value: 'bg-gray-300', label: '회색', textColor: 'text-gray-800' },
    { value: 'bg-orange-300', label: '주황색', textColor: 'text-orange-800' },
  ];

  const getTextColor = (bgColor: string) => {
    const colorMap = availableColors.find(c => c.value === bgColor);
    return colorMap?.textColor || 'text-gray-800';
  };

  const existingTagNames = new Set(existingTags.map(tag => tag.name));

  const allTags = [
    ...existingTags.map(tag => ({ ...tag, isExisting: true })),
    ...(availableTags
      ? availableTags.filter(tag => !existingTagNames.has(tag.name)).map(tag => ({ ...tag, isExisting: false }))
      : PREDEFINED_TAGS
          .filter(tag => !existingTagNames.has(tag.name))
          .map(tag => ({
            id: -1,
            name: tag.name,
            color: tag.color,
            createdBy: '시스템',
            createdAt: '',
            isExisting: false,
          }))),
  ];

  const filteredTags = allTags.filter(tag =>
    tag.name.toLowerCase().includes(filterText.toLowerCase())
  );

  useEffect(() => {
    if (isOpen) {
      setFilterText('');
      setNewTagColor('bg-gray-300');
      setShowColorPicker(false);
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (colorPickerRef.current && !colorPickerRef.current.contains(event.target as Node)) {
        setShowColorPicker(false);
      }
    };

    if (showColorPicker) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [showColorPicker]);

  if (!isOpen) return null;

  const handleTagToggle = (tag: typeof allTags[0]) => {
    if (tag.isExisting) {
      onRemoveTag(tag.id);
    } else {
      onAddTag(tag.name, tag.color);
    }
  };

  const handleAddNewTag = () => {
    const trimmedName = filterText.trim();
    if (trimmedName && !existingTagNames.has(trimmedName)) {
      onAddTag(trimmedName, newTagColor);
      setFilterText('');
      setNewTagColor('bg-gray-300');
      setShowColorPicker(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && filterText.trim()) {
      e.preventDefault();
      handleAddNewTag();
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  const isCreatingNew =
    filterText.trim().length > 0 && !allTags.some(tag => tag.name === filterText.trim());

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-[400px] max-w-90vw max-h-90vh overflow-y-auto shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-800">고객에게 태그 추가</h3>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded transition-colors">
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        <div className="relative mb-4">
          <input
            ref={inputRef}
            type="text"
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="태그 검색 또는 새 태그 입력..."
            className="w-full pl-4 pr-16 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            maxLength={20}
          />

          {isCreatingNew && (
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center gap-2">
              <button
                onClick={() => setShowColorPicker(!showColorPicker)}
                className="p-1 hover:bg-gray-100 rounded transition-colors"
                title="색상 선택"
                type="button"
              >
                <div
                  className={`w-5 h-5 rounded-full ${newTagColor} border border-gray-300 hover:border-gray-500 transition-colors`}
                />
              </button>
              <span className="text-xs text-gray-400">{filterText.length}/20</span>
            </div>
          )}

          {showColorPicker && isCreatingNew && (
            <div
              ref={colorPickerRef}
              className="absolute top-full right-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg p-3 z-50"
            >
              <div className="grid grid-cols-4 gap-2">
                {availableColors.map((color) => (
                  <button
                    key={color.value}
                    onClick={() => {
                      setNewTagColor(color.value);
                      setShowColorPicker(false);
                    }}
                    className={`w-8 h-8 rounded-full ${color.value} border-2 ${
                      newTagColor === color.value ? 'border-gray-600' : 'border-gray-300'
                    } hover:border-gray-500 transition-colors`}
                    title={color.label}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {isCreatingNew && (
          <div className="mb-4">
            <div
              className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${newTagColor} ${getTextColor(
                newTagColor
              )}`}
            >
              <Hash size={12} className="mr-1" />
              {filterText.trim()}
            </div>

            {existingTagNames.has(filterText.trim()) && (
              <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-sm text-red-700">
                이미 존재하는 태그입니다.
              </div>
            )}

            <div className="mt-2 text-xs text-gray-500">Enter 키를 눌러 태그를 추가하세요</div>
          </div>
        )}

        {!isCreatingNew && filteredTags.length > 0 && (
          <div className="space-y-2">
            {filteredTags.map((tag, index) => (
              <div
                key={tag.isExisting ? tag.id : `predefined-${index}`}
                onClick={() => handleTagToggle(tag)}
                className={`w-full flex items-center gap-3 p-3 border rounded-lg cursor-pointer transition-all ${
                  tag.isExisting
                    ? 'bg-blue-50 border-blue-200'
                    : 'border-gray-200 hover:bg-gray-50 hover:border-gray-300'
                }`}
              >
                <div
                  className={`w-5 h-5 border-2 rounded flex items-center justify-center ${
                    tag.isExisting ? 'bg-blue-500 border-blue-500' : 'border-gray-300'
                  }`}
                >
                  {tag.isExisting && <Check size={12} className="text-white" />}
                </div>
                <div
                  className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                    tag.color
                  } ${getTextColor(tag.color)}`}
                >
                  <Hash size={12} className="mr-1" />
                  {tag.name}
                </div>
              </div>
            ))}
          </div>
        )}

        {!isCreatingNew && filteredTags.length === 0 && (
          <div className="text-center py-8 text-gray-500 text-sm">
            <Hash size={32} className="mx-auto mb-2 opacity-50" />
            <p>검색 결과가 없습니다.</p>
            <p className="text-xs mt-1">새로운 태그를 입력하여 생성하세요.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TagSelectionModal;
