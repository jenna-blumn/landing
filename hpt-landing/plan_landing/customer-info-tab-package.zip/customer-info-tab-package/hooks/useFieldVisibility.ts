import { useState, useCallback } from 'react';
import { getDefaultVisibleFields } from '../utils/fieldDefinitions';

export const useFieldVisibility = (initialVisibleFields?: Set<string>) => {
  const [visibleFields, setVisibleFields] = useState<Set<string>>(
    initialVisibleFields || getDefaultVisibleFields()
  );
  const [columnSettings, setColumnSettings] = useState<Set<string>>(new Set());

  const toggleFieldVisibility = useCallback((fieldId: string) => {
    setVisibleFields(prev => {
      const newSet = new Set(prev);
      if (newSet.has(fieldId)) {
        newSet.delete(fieldId);
      } else {
        newSet.add(fieldId);
      }
      return newSet;
    });
  }, []);

  const toggleColumnSetting = useCallback((fieldId: string) => {
    setColumnSettings(prev => {
      const newSet = new Set(prev);
      if (newSet.has(fieldId)) {
        newSet.delete(fieldId);
      } else {
        newSet.add(fieldId);
      }
      return newSet;
    });
  }, []);

  const showAllFields = useCallback(() => {
    setVisibleFields(new Set(['name', 'email', 'phone', 'company', 'status', 'birthDate', 'address', 'customerId', 'lastConsultation']));
  }, []);

  const hideAllFields = useCallback(() => {
    setVisibleFields(new Set(['name', 'email']));
  }, []);

  return {
    visibleFields,
    columnSettings,
    toggleFieldVisibility,
    toggleColumnSetting,
    showAllFields,
    hideAllFields,
    setVisibleFields,
    setColumnSettings,
  };
};
