import { useState, useCallback } from 'react';
import { SectionConfig, Memo, Tag } from '../types';

export const useCustomerInfoState = (initialSections: SectionConfig[]) => {
  const [sections, setSections] = useState<SectionConfig[]>(initialSections);
  const [draggedSectionId, setDraggedSectionId] = useState<string | null>(null);

  const handleDragStart = useCallback((sectionId: string) => {
    setDraggedSectionId(sectionId);
  }, []);

  const handleDragEnd = useCallback(() => {
    setDraggedSectionId(null);
  }, []);

  const handleDrop = useCallback((targetSectionId: string, draggedId: string) => {
    if (!draggedId || draggedId === targetSectionId) {
      return sections;
    }

    setSections(prevSections => {
      const newSections = [...prevSections];
      const draggedIndex = newSections.findIndex(s => s.id === draggedId);
      const targetIndex = newSections.findIndex(s => s.id === targetSectionId);

      if (draggedIndex === -1 || targetIndex === -1) {
        return prevSections;
      }

      const [draggedSection] = newSections.splice(draggedIndex, 1);
      newSections.splice(targetIndex, 0, draggedSection);

      return newSections.map((section, index) => ({
        ...section,
        order: index,
      }));
    });

    setDraggedSectionId(null);
    return sections;
  }, [sections]);

  const updateSectionSettings = useCallback((sectionId: string, settings: Partial<SectionConfig>) => {
    setSections(prevSections =>
      prevSections.map(section =>
        section.id === sectionId
          ? { ...section, ...settings }
          : section
      )
    );
  }, []);

  return {
    sections,
    setSections,
    draggedSectionId,
    handleDragStart,
    handleDragEnd,
    handleDrop,
    updateSectionSettings,
  };
};

export const useMemoManagement = (initialMemos: Memo[] = []) => {
  const [memos, setMemos] = useState<Memo[]>(initialMemos);

  const addMemo = useCallback((content: string) => {
    const newMemo: Memo = {
      id: Date.now(),
      content: content.trim(),
      author: '현재 상담사',
      createdAt: new Date().toLocaleString('ko-KR'),
    };
    setMemos(prev => [newMemo, ...prev]);
    return newMemo;
  }, []);

  const editMemo = useCallback((memoId: number, newContent: string) => {
    setMemos(prev =>
      prev.map(memo =>
        memo.id === memoId
          ? { ...memo, content: newContent }
          : memo
      )
    );
  }, []);

  const deleteMemo = useCallback((memoId: number) => {
    setMemos(prev => prev.filter(memo => memo.id !== memoId));
  }, []);

  return {
    memos,
    setMemos,
    addMemo,
    editMemo,
    deleteMemo,
  };
};

export const useTagManagement = (initialTags: Tag[] = []) => {
  const [tags, setTags] = useState<Tag[]>(initialTags);

  const addTag = useCallback((name: string, color: string) => {
    const newTag: Tag = {
      id: Date.now(),
      name,
      color,
      createdBy: '현재 상담사',
      createdAt: new Date().toLocaleString('ko-KR'),
    };
    setTags(prev => [...prev, newTag]);
    return newTag;
  }, []);

  const editTag = useCallback((tagId: number, newName: string, newColor: string) => {
    setTags(prev =>
      prev.map(tag =>
        tag.id === tagId
          ? { ...tag, name: newName, color: newColor }
          : tag
      )
    );
  }, []);

  const deleteTag = useCallback((tagId: number) => {
    setTags(prev => prev.filter(tag => tag.id !== tagId));
  }, []);

  return {
    tags,
    setTags,
    addTag,
    editTag,
    deleteTag,
  };
};
