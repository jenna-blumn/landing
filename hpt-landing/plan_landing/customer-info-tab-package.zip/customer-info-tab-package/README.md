# Customer Info Tab Package

A comprehensive, reusable React component package for displaying and managing customer information with drag-and-drop sections, field visibility management, memos, tags, and full customization support.

## Features

- ✨ **Drag-and-drop section reordering** - Organize sections to fit your workflow
- 📊 **Field visibility management** - Show/hide specific customer information fields
- 📝 **Memo management** - Add, edit, and delete customer notes
- 🏷️ **Tag system** - Categorize customers with customizable colored tags
- 📋 **Copy to clipboard** - Quick copy functionality for all fields
- 🔧 **Fully customizable** - Custom sections, renderers, and styling
- 💾 **API ready** - Built-in hooks for external data management
- 📱 **Responsive design** - Works on all screen sizes
- ⚡ **TypeScript support** - Full type safety included

## Installation

```bash
npm install customer-info-tab-package
# or
yarn add customer-info-tab-package
```

### Peer Dependencies

Make sure you have these installed:

```bash
npm install react react-dom lucide-react
```

## Quick Start

```tsx
import React from 'react';
import { CustomerInfoTabContainer } from 'customer-info-tab-package';

function App() {
  const customerData = {
    name: '김철수',
    email: 'kim@example.com',
    phone: '+82-10-1234-5678',
    customerId: 'cust-12345',
  };

  return (
    <div className="h-screen">
      <CustomerInfoTabContainer customerData={customerData} />
    </div>
  );
}
```

## Table of Contents

1. [Basic Usage](#basic-usage)
2. [Props API](#props-api)
3. [Default Sections](#default-sections)
4. [Custom Sections](#custom-sections)
5. [Custom Renderers](#custom-renderers)
6. [Field Visibility](#field-visibility)
7. [API Integration](#api-integration)
8. [Advanced Examples](#advanced-examples)
9. [Styling](#styling)
10. [TypeScript](#typescript)

---

## Basic Usage

### Minimal Setup

```tsx
import { CustomerInfoTabContainer } from 'customer-info-tab-package';

<CustomerInfoTabContainer
  customerData={{
    name: '김철수',
    email: 'kim@example.com',
    customerId: 'cust-12345',
  }}
/>
```

### With Event Handlers

```tsx
import { CustomerInfoTabContainer } from 'customer-info-tab-package';

function MyComponent() {
  const handleMemoAdd = (content: string) => {
    console.log('New memo:', content);
  };

  const handleTagAdd = (name: string, color: string) => {
    console.log('New tag:', name, color);
  };

  return (
    <CustomerInfoTabContainer
      customerData={customerData}
      onAddMemo={handleMemoAdd}
      onAddTag={handleTagAdd}
    />
  );
}
```

---

## Props API

### CustomerInfoTabProps

| Prop | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| `customerData` | `CustomerInfo` | No | Mock data | Customer information object |
| `sections` | `SectionConfig[]` | No | Default sections | Array of section configurations |
| `customSections` | `CustomSection[]` | No | `[]` | Custom sections to add |
| `visibleFields` | `Set<string>` | No | Default fields | Set of visible field IDs |
| `onToggleFieldVisibility` | `(fieldId: string) => void` | No | - | Field visibility toggle handler |
| `columnSettings` | `Set<string>` | No | `new Set()` | Fields that span full width |
| `onToggleColumnSetting` | `(fieldId: string) => void` | No | - | Column setting toggle handler |
| `memos` | `Memo[]` | No | `[]` | Array of memo objects |
| `onAddMemo` | `(content: string) => void` | No | - | Memo add handler |
| `onEditMemo` | `(id: number, content: string) => void` | No | - | Memo edit handler |
| `onDeleteMemo` | `(id: number) => void` | No | - | Memo delete handler |
| `tags` | `Tag[]` | No | `[]` | Array of tag objects |
| `onAddTag` | `(name: string, color: string) => void` | No | - | Tag add handler |
| `onEditTag` | `(id: number, name: string, color: string) => void` | No | - | Tag edit handler |
| `onDeleteTag` | `(id: number) => void` | No | - | Tag delete handler |
| `customerInfoRenderer` | `Function` | No | - | Custom customer info renderer |
| `customerMemoRenderer` | `Function` | No | - | Custom memo renderer |
| `customerTagRenderer` | `Function` | No | - | Custom tag renderer |
| `isCustomerInfoOverlayOpen` | `boolean` | No | `false` | Overlay open state |
| `onToggleCustomerInfoOverlay` | `(open: boolean) => void` | No | - | Overlay toggle handler |
| `onSectionReorder` | `(sections: SectionConfig[]) => void` | No | - | Section reorder handler |
| `className` | `string` | No | `''` | Container CSS class |
| `sectionClassName` | `string` | No | `''` | Section CSS class |

### CustomerInfo Type

```typescript
interface CustomerInfo {
  name: string;
  email: string;
  customerId: string;
  phone?: string;
  birthDate?: string;
  address?: string;
  company?: string;
  gender?: string;
  status?: string;
  lastConsultation?: string;
  [key: string]: any;  // Support custom fields
}
```

### Memo Type

```typescript
interface Memo {
  id: number;
  content: string;
  author: string;
  createdAt: string;
}
```

### Tag Type

```typescript
interface Tag {
  id: number;
  name: string;
  color: string;  // Tailwind CSS class (e.g., 'bg-blue-300')
  createdBy: string;
  createdAt: string;
}
```

---

## Default Sections

The package includes three default sections:

### 1. Customer Info Section
Displays customer details with:
- Automatic field layout (1 or 2 columns)
- Copy-to-clipboard for all fields
- Hover tooltips for long values
- Field visibility management

### 2. Customer Memo Section
Memo management with:
- Add new memos
- Edit existing memos (Ctrl+Enter to save)
- Delete memos
- Author and timestamp tracking

### 3. Customer Tag Section
Tag management with:
- Add tags with custom colors
- Delete tags
- Tag search/filter
- Predefined tag suggestions
- Maximum 20 tags per customer

---

## Custom Sections

### Adding Custom Sections

```tsx
import { CustomerInfoTabContainer, CustomSection } from 'customer-info-tab-package';

const customSections: CustomSection[] = [
  {
    section: {
      id: 'purchase-history',
      name: '구매 이력',
      type: 'custom',
      order: 3,
      isCollapsed: false,
    },
    renderContent: (customerData) => (
      <div className="space-y-2">
        <div className="border rounded p-3">
          <div className="font-medium">Product A</div>
          <div className="text-sm text-gray-600">₩150,000 - 2024-01-15</div>
        </div>
        <div className="border rounded p-3">
          <div className="font-medium">Product B</div>
          <div className="text-sm text-gray-600">₩89,000 - 2024-01-10</div>
        </div>
      </div>
    ),
  },
];

<CustomerInfoTabContainer
  customerData={customerData}
  customSections={customSections}
/>
```

### Multiple Custom Sections

```tsx
const customSections: CustomSection[] = [
  {
    section: {
      id: 'preferences',
      name: '고객 선호사항',
      type: 'custom',
      order: 3,
      isCollapsed: false,
    },
    renderContent: (data) => (
      <div>Customer preferences content</div>
    ),
  },
  {
    section: {
      id: 'activity',
      name: '활동 로그',
      type: 'custom',
      order: 4,
      isCollapsed: false,
    },
    renderContent: (data) => (
      <div>Activity log content</div>
    ),
  },
];
```

---

## Custom Renderers

Replace default section renderers with your own:

### Customer Info Renderer

```tsx
import { CustomerInfo } from 'customer-info-tab-package';

const customInfoRenderer = (data: CustomerInfo, props: any) => (
  <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg">
    <div className="flex items-center gap-3">
      <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white text-xl font-bold">
        {data.name[0]}
      </div>
      <div>
        <h3 className="text-xl font-bold">{data.name}</h3>
        <p className="text-sm text-gray-600">{data.email}</p>
      </div>
    </div>
  </div>
);

<CustomerInfoTabContainer
  customerData={customerData}
  customerInfoRenderer={customInfoRenderer}
/>
```

### Memo Renderer

```tsx
import { Memo } from 'customer-info-tab-package';

const customMemoRenderer = (
  memos: Memo[],
  handlers: { addMemo, editMemo, deleteMemo }
) => (
  <div className="space-y-2">
    {memos.map((memo) => (
      <div key={memo.id} className="bg-yellow-50 border-l-4 border-yellow-400 p-3">
        <div className="font-medium">{memo.author}</div>
        <div className="text-sm">{memo.content}</div>
        <button onClick={() => handlers.deleteMemo(memo.id)}>
          Delete
        </button>
      </div>
    ))}
  </div>
);

<CustomerInfoTabContainer
  customerData={customerData}
  customerMemoRenderer={customMemoRenderer}
/>
```

### Tag Renderer

```tsx
import { Tag } from 'customer-info-tab-package';

const customTagRenderer = (
  tags: Tag[],
  handlers: { addTag, editTag, deleteTag }
) => (
  <div className="flex flex-wrap gap-2">
    {tags.map((tag) => (
      <span
        key={tag.id}
        className="px-3 py-1 bg-gradient-to-r from-purple-400 to-pink-400 text-white rounded-full"
      >
        {tag.name}
      </span>
    ))}
  </div>
);

<CustomerInfoTabContainer
  customerData={customerData}
  customerTagRenderer={customTagRenderer}
/>
```

---

## Field Visibility

### Using Built-in Hook

```tsx
import { CustomerInfoTabContainer, useFieldVisibility } from 'customer-info-tab-package';

function MyComponent() {
  const {
    visibleFields,
    columnSettings,
    toggleFieldVisibility,
    toggleColumnSetting,
  } = useFieldVisibility();

  return (
    <>
      <div className="mb-4">
        <button onClick={() => toggleFieldVisibility('phone')}>
          Toggle Phone Visibility
        </button>
        <button onClick={() => toggleColumnSetting('address')}>
          Toggle Address Full Width
        </button>
      </div>

      <CustomerInfoTabContainer
        customerData={customerData}
        visibleFields={visibleFields}
        onToggleFieldVisibility={toggleFieldVisibility}
        columnSettings={columnSettings}
        onToggleColumnSetting={toggleColumnSetting}
      />
    </>
  );
}
```

### Custom Visibility Management

```tsx
function MyComponent() {
  const [visibleFields, setVisibleFields] = useState(
    new Set(['name', 'email', 'phone', 'company'])
  );

  const toggleField = (fieldId: string) => {
    setVisibleFields((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(fieldId)) {
        newSet.delete(fieldId);
      } else {
        newSet.add(fieldId);
      }
      return newSet;
    });
  };

  return (
    <CustomerInfoTabContainer
      customerData={customerData}
      visibleFields={visibleFields}
      onToggleFieldVisibility={toggleField}
    />
  );
}
```

---

## API Integration

### Full API Integration Example

```tsx
import { useState, useEffect } from 'react';
import { CustomerInfoTabContainer, CustomerInfo, Memo, Tag } from 'customer-info-tab-package';

function MyComponent() {
  const [customerData, setCustomerData] = useState<CustomerInfo>();
  const [memos, setMemos] = useState<Memo[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);

  useEffect(() => {
    // Fetch customer data from API
    fetch('/api/customers/123')
      .then(res => res.json())
      .then(data => setCustomerData(data));

    // Fetch memos
    fetch('/api/customers/123/memos')
      .then(res => res.json())
      .then(data => setMemos(data));

    // Fetch tags
    fetch('/api/customers/123/tags')
      .then(res => res.json())
      .then(data => setTags(data));
  }, []);

  const handleAddMemo = async (content: string) => {
    const response = await fetch('/api/memos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ customerId: '123', content }),
    });
    const newMemo = await response.json();
    setMemos(prev => [newMemo, ...prev]);
  };

  const handleEditMemo = async (memoId: number, content: string) => {
    await fetch(`/api/memos/${memoId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content }),
    });
    setMemos(prev =>
      prev.map(memo => (memo.id === memoId ? { ...memo, content } : memo))
    );
  };

  const handleDeleteMemo = async (memoId: number) => {
    await fetch(`/api/memos/${memoId}`, { method: 'DELETE' });
    setMemos(prev => prev.filter(memo => memo.id !== memoId));
  };

  const handleAddTag = async (name: string, color: string) => {
    const response = await fetch('/api/tags', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ customerId: '123', name, color }),
    });
    const newTag = await response.json();
    setTags(prev => [...prev, newTag]);
  };

  const handleDeleteTag = async (tagId: number) => {
    await fetch(`/api/tags/${tagId}`, { method: 'DELETE' });
    setTags(prev => prev.filter(tag => tag.id !== tagId));
  };

  return (
    <CustomerInfoTabContainer
      customerData={customerData}
      memos={memos}
      onAddMemo={handleAddMemo}
      onEditMemo={handleEditMemo}
      onDeleteMemo={handleDeleteMemo}
      tags={tags}
      onAddTag={handleAddTag}
      onDeleteTag={handleDeleteTag}
    />
  );
}
```

---

## Advanced Examples

### Combining All Features

```tsx
import {
  CustomerInfoTabContainer,
  useFieldVisibility,
  useMemoManagement,
  useTagManagement,
} from 'customer-info-tab-package';

function AdvancedExample() {
  const fieldVisibility = useFieldVisibility();
  const memoManagement = useMemoManagement();
  const tagManagement = useTagManagement();

  const customSections = [
    {
      section: {
        id: 'custom-analytics',
        name: '분석',
        type: 'custom',
        order: 4,
        isCollapsed: false,
      },
      renderContent: () => <div>Analytics content</div>,
    },
  ];

  return (
    <CustomerInfoTabContainer
      customerData={customerData}
      visibleFields={fieldVisibility.visibleFields}
      onToggleFieldVisibility={fieldVisibility.toggleFieldVisibility}
      columnSettings={fieldVisibility.columnSettings}
      memos={memoManagement.memos}
      onAddMemo={memoManagement.addMemo}
      onEditMemo={memoManagement.editMemo}
      onDeleteMemo={memoManagement.deleteMemo}
      tags={tagManagement.tags}
      onAddTag={tagManagement.addTag}
      onDeleteTag={tagManagement.deleteTag}
      customSections={customSections}
    />
  );
}
```

---

## Styling

### Custom Classes

```tsx
<CustomerInfoTabContainer
  customerData={customerData}
  className="custom-container-class"
  sectionClassName="custom-section-class"
/>
```

### Tailwind CSS

The package uses Tailwind CSS. Make sure your Tailwind config includes the package:

```js
// tailwind.config.js
module.exports = {
  content: [
    './src/**/*.{js,jsx,ts,tsx}',
    './node_modules/customer-info-tab-package/**/*.{js,tsx}',
  ],
  // ...
};
```

---

## TypeScript

The package is fully typed. Import types as needed:

```typescript
import type {
  CustomerInfo,
  Memo,
  Tag,
  SectionConfig,
  CustomSection,
  CustomerInfoTabProps,
  FieldDefinition,
} from 'customer-info-tab-package';
```

---

## Available Field IDs

Fields you can show/hide using `visibleFields`:

**Basic Info:** `name`, `company`, `type`, `status`, `accountId`, `birthDate`, `age`, `gender`, `authentication`

**Contact:** `email`, `phone`, `businessPhone`, `businessEmail`, `kakaoId`, `naverTalkId`, `instagramId`, `whatsappId`, `zaloId`

**Address:** `address`, `deliveryAddress`

**System:** `customerId`, `emailDomain`, `os`, `browser`, `browserLanguage`

**Activity:** `firstSeen`, `signedUp`, `lastSeen`, `lastContacted`, `lastHeardFrom`, `lastOpenedEmail`, `lastClickedOnLink`, `lastConsultation`

**Other:** `conversationRating`, `customAttribute1` through `customAttribute10`

---

## License

MIT

## Support

For issues and questions, please open an issue on GitHub.
