export { default as CustomerInfoTabContainer } from './components/CustomerInfoTabContainer';
export { default as SectionWrapper } from './components/SectionWrapper';
export { default as CustomerInfoSection } from './components/sections/CustomerInfoSection';
export { default as CustomerMemoSection } from './components/sections/CustomerMemoSection';
export { default as CustomerTagSection } from './components/sections/CustomerTagSection';
export { default as TagSelectionModal } from './components/modals/TagSelectionModal';

export * from './types';
export * from './hooks/useCustomerInfoState';
export * from './hooks/useFieldVisibility';
export * from './utils/fieldDefinitions';
export * from './utils/copyToClipboard';
