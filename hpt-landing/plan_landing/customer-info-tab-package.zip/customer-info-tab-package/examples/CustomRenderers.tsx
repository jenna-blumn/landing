import React from 'react';
import { CustomerInfoTabContainer, CustomerInfo, Memo, Tag } from '../index';
import { User } from 'lucide-react';

const CustomRenderersExample: React.FC = () => {
  const customerData: CustomerInfo = {
    name: '박민수',
    email: 'park@example.com',
    phone: '+82-10-5555-6666',
    company: 'LG전자',
    customerId: 'cust-11111',
  };

  const customInfoRenderer = (data: CustomerInfo) => (
    <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center text-white text-2xl font-bold">
          {data.name[0]}
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-800">{data.name}</h3>
          <p className="text-sm text-gray-600">{data.company}</p>
        </div>
      </div>
      <div className="space-y-2">
        <div className="bg-white p-2 rounded shadow-sm">
          <span className="text-xs text-gray-500">이메일:</span>
          <div className="font-medium text-sm">{data.email}</div>
        </div>
        <div className="bg-white p-2 rounded shadow-sm">
          <span className="text-xs text-gray-500">전화:</span>
          <div className="font-medium text-sm">{data.phone}</div>
        </div>
        <div className="bg-white p-2 rounded shadow-sm">
          <span className="text-xs text-gray-500">고객 ID:</span>
          <div className="font-mono text-sm">{data.customerId}</div>
        </div>
      </div>
    </div>
  );

  const customMemoRenderer = (memos: Memo[], handlers: any) => (
    <div className="space-y-3">
      <h4 className="font-semibold text-gray-700 flex items-center gap-2">
        <User size={16} />
        메모 ({memos.length})
      </h4>
      {memos.map((memo) => (
        <div key={memo.id} className="bg-yellow-50 border-l-4 border-yellow-400 p-3 rounded">
          <div className="text-sm font-medium text-gray-800 mb-1">{memo.author}</div>
          <div className="text-sm text-gray-700">{memo.content}</div>
          <div className="text-xs text-gray-500 mt-2">{memo.createdAt}</div>
        </div>
      ))}
    </div>
  );

  const customTagRenderer = (tags: Tag[], handlers: any) => (
    <div className="flex flex-wrap gap-2">
      {tags.map((tag) => (
        <div
          key={tag.id}
          className="px-4 py-2 bg-gradient-to-r from-purple-400 to-pink-400 text-white rounded-full text-sm font-medium shadow-md"
        >
          {tag.name}
        </div>
      ))}
      {tags.length === 0 && (
        <div className="text-gray-400 text-sm">태그가 없습니다</div>
      )}
    </div>
  );

  return (
    <div className="h-screen p-4">
      <h1 className="text-2xl font-bold mb-4">Custom Renderers Example</h1>
      <div className="h-[calc(100vh-6rem)] border rounded-lg">
        <CustomerInfoTabContainer
          customerData={customerData}
          customerInfoRenderer={customInfoRenderer}
          customerMemoRenderer={customMemoRenderer}
          customerTagRenderer={customTagRenderer}
        />
      </div>
    </div>
  );
};

export default CustomRenderersExample;
