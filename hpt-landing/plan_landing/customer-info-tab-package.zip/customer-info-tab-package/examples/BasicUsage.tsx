import React from 'react';
import { CustomerInfoTabContainer } from '../index';

const BasicUsageExample: React.FC = () => {
  const customerData = {
    name: '김철수',
    email: 'kim@example.com',
    phone: '+82-10-1234-5678',
    company: '삼성전자',
    customerId: 'cust-12345',
    status: 'VIP',
    address: '서울시 강남구',
    birthDate: '1985-03-15',
  };

  return (
    <div className="h-screen p-4">
      <h1 className="text-2xl font-bold mb-4">Basic Usage Example</h1>
      <div className="h-[calc(100vh-6rem)] border rounded-lg">
        <CustomerInfoTabContainer customerData={customerData} />
      </div>
    </div>
  );
};

export default BasicUsageExample;
