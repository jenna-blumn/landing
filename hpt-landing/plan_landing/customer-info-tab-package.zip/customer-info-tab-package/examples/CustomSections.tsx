import React from 'react';
import { CustomerInfoTabContainer, SectionConfig, CustomSection } from '../index';

const CustomSectionsExample: React.FC = () => {
  const customerData = {
    name: '이영희',
    email: 'lee@example.com',
    phone: '+82-10-9876-5432',
    customerId: 'cust-67890',
  };

  const customSections: CustomSection[] = [
    {
      section: {
        id: 'custom-preferences',
        name: '고객 선호사항',
        type: 'custom',
        order: 3,
        isCollapsed: false,
      },
      renderContent: (data) => (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-gray-600">선호 연락 방법:</span>
            <span className="text-sm text-gray-800">이메일</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-gray-600">선호 언어:</span>
            <span className="text-sm text-gray-800">한국어</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-gray-600">마케팅 수신 동의:</span>
            <span className="text-sm text-green-600">동의</span>
          </div>
        </div>
      ),
    },
    {
      section: {
        id: 'custom-purchase-history',
        name: '구매 이력',
        type: 'custom',
        order: 4,
        isCollapsed: false,
      },
      renderContent: () => (
        <div className="space-y-3">
          <div className="border rounded-lg p-3 bg-gray-50">
            <div className="font-medium text-sm mb-1">제품 A - 2024-01-15</div>
            <div className="text-xs text-gray-600">₩150,000</div>
          </div>
          <div className="border rounded-lg p-3 bg-gray-50">
            <div className="font-medium text-sm mb-1">제품 B - 2024-01-10</div>
            <div className="text-xs text-gray-600">₩89,000</div>
          </div>
          <div className="text-sm text-gray-500 text-center mt-2">
            총 구매액: ₩239,000
          </div>
        </div>
      ),
    },
  ];

  return (
    <div className="h-screen p-4">
      <h1 className="text-2xl font-bold mb-4">Custom Sections Example</h1>
      <div className="h-[calc(100vh-6rem)] border rounded-lg">
        <CustomerInfoTabContainer
          customerData={customerData}
          customSections={customSections}
        />
      </div>
    </div>
  );
};

export default CustomSectionsExample;
