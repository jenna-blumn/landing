import React, { useState, useEffect } from 'react';
import { CustomerInfoTabContainer, CustomerInfo, Memo, Tag } from '../index';

const WithApiIntegrationExample: React.FC = () => {
  const [customerData, setCustomerData] = useState<CustomerInfo | undefined>(undefined);
  const [memos, setMemos] = useState<Memo[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCustomerData();
  }, []);

  const fetchCustomerData = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));

      setCustomerData({
        name: '최유진',
        email: 'choi@example.com',
        phone: '+82-10-7777-8888',
        company: '현대자동차',
        customerId: 'cust-99999',
        status: 'VIP',
        address: '서울시 서초구',
        birthDate: '1990-07-20',
      });

      setMemos([
        {
          id: 1,
          content: '고객이 프리미엄 서비스에 관심 있음',
          author: '상담사 김철수',
          createdAt: '2024-01-20 10:30',
        },
        {
          id: 2,
          content: '다음 주 제품 데모 예정',
          author: '상담사 이영희',
          createdAt: '2024-01-21 14:15',
        },
      ]);

      setTags([
        {
          id: 1,
          name: 'VIP고객',
          color: 'bg-red-300',
          createdBy: '시스템',
          createdAt: '2024-01-15',
        },
        {
          id: 2,
          name: '프리미엄관심',
          color: 'bg-purple-300',
          createdBy: '상담사 김철수',
          createdAt: '2024-01-20',
        },
      ]);
    } catch (error) {
      console.error('Failed to fetch customer data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddMemo = async (content: string) => {
    console.log('API call: Adding memo', content);

    const newMemo: Memo = {
      id: Date.now(),
      content,
      author: '현재 상담사',
      createdAt: new Date().toLocaleString('ko-KR'),
    };

    setMemos(prev => [newMemo, ...prev]);
  };

  const handleEditMemo = async (memoId: number, newContent: string) => {
    console.log('API call: Editing memo', memoId, newContent);

    setMemos(prev =>
      prev.map(memo =>
        memo.id === memoId ? { ...memo, content: newContent } : memo
      )
    );
  };

  const handleDeleteMemo = async (memoId: number) => {
    console.log('API call: Deleting memo', memoId);

    setMemos(prev => prev.filter(memo => memo.id !== memoId));
  };

  const handleAddTag = async (name: string, color: string) => {
    console.log('API call: Adding tag', name, color);

    const newTag: Tag = {
      id: Date.now(),
      name,
      color,
      createdBy: '현재 상담사',
      createdAt: new Date().toLocaleString('ko-KR'),
    };

    setTags(prev => [...prev, newTag]);
  };

  const handleDeleteTag = async (tagId: number) => {
    console.log('API call: Deleting tag', tagId);

    setTags(prev => prev.filter(tag => tag.id !== tagId));
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <div className="text-gray-600">Loading customer data...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen p-4">
      <h1 className="text-2xl font-bold mb-2">API Integration Example</h1>
      <p className="text-gray-600 mb-4">
        This example demonstrates integration with external APIs for real-time data management.
      </p>
      <div className="h-[calc(100vh-8rem)] border rounded-lg">
        <CustomerInfoTabContainer
          customerData={customerData}
          memos={memos}
          onAddMemo={handleAddMemo}
          onEditMemo={handleEditMemo}
          onDeleteMemo={handleDeleteMemo}
          tags={tags}
          onAddTag={handleAddTag}
          onDeleteTag={handleDeleteTag}
        />
      </div>
    </div>
  );
};

export default WithApiIntegrationExample;
